#!/bin/bash
# install any software required (Ubuntu)
echo 'debconf debconf/frontend select Noninteractive' | debconf-set-selections
add-apt-repository main
add-apt-repository universe
add-apt-repository restricted
add-apt-repository multiverse
apt-get update

# gradescope helpers
pip install subprocess32 gradescope-utils
pip3 install gradescope-utils

# Install required packages for python
apt-get install -y python3-pip python3-dev
pip3 install --upgrade pip

# install any software required (Ubuntu)
echo 'debconf debconf/frontend select Noninteractive' | debconf-set-selections
add-apt-repository main
add-apt-repository universe
add-apt-repository restricted
add-apt-repository multiverse
apt-get update

# gradescope helpers
pip install subprocess32 gradescope-utils
pip3 install gradescope-utils


### copied from csc412 dockerfile
# install GCC-related packages
apt-get -y install\
 binutils-doc\
 cpp-doc\
 gcc-doc\
 g++\
 g++-multilib\
 gdb\
 gdb-doc\
 glibc-doc\
 libblas-dev\
 liblapack-dev\
 liblapack-doc\
 libstdc++-10-doc\
 make\
 make-doc

# install clang-related packages
apt-get -y install\
 clang\
 clang-format

# install benchmarking tools
apt-get -y install\
 hyperfine\
 time\
 valgrind
