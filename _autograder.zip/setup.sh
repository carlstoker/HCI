#!/bin/bash
# install any software required (Ubuntu)
echo 'debconf debconf/frontend select Noninteractive' | debconf-set-selections
add-apt-repository main
add-apt-repository universe
add-apt-repository restricted
add-apt-repository multiverse
apt-get update

# gradescope helpers
pip install subprocess32 gradescope-utils
pip3 install gradescope-utils

# Install required packages for python
apt-get install -y python3-pip python3-dev
pip3 install --upgrade pip