import os
import subprocess
import unittest
from gradescope_utils.autograder_utils.decorators import weight, visibility, number

# Student directory
student_dir = '/autograder/submission'

# Test cases
class TestCase(unittest.TestCase):
    @number('a01')
    @weight(100)
    @visibility('visible')
    def test_a01(self):
        # Change to student directory
        os.chdir(student_dir)
        # Run the student's program
        result = subprocess.run(['python3', 'a01.py'], stdout=subprocess.PIPE)
        # Check the output
        self.assertEqual(result.stdout.decode('utf-8'), 'Hello, World!\n')
